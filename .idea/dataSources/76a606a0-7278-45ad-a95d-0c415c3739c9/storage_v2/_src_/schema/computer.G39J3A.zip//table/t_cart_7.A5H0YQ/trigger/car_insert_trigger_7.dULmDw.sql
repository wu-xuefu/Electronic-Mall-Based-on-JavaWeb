create definer = root@localhost trigger car_insert_trigger_7
    before insert
    on t_cart_7
    for each row
begin        set NEW.name = (select name from t_goods where t_goods.id = NEW.id);        set NEW.price = (select value from t_goods where t_goods.id = NEW.id);    end;

