create definer = root@localhost trigger car_insert_trigger
    before insert
    on t_cart_1
    for each row
begin
        set NEW.name = (select name from t_goods where t_goods.id = NEW.id);
        set NEW.price = (select value from t_goods where t_goods.id = NEW.id);
    end;

