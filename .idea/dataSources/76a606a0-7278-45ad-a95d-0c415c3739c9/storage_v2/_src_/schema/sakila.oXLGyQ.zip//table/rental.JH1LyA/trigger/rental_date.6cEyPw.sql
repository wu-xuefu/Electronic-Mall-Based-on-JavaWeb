create definer = root@localhost trigger rental_date
    before insert
    on rental
    for each row
    SET NEW.rental_date = NOW();

